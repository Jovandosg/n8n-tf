import json
import os
import requests
import boto3

def lambda_handler(event, context):
    """
    Função Lambda para processar mensagens da SQS e enviá-las para o webhook do n8n.
    """
    WEBHOOK_URL = os.environ.get("N8N_WEBHOOK_URL")
    SQS_QUEUE_URL = os.environ.get("SQS_QUEUE_URL")
    
    if not WEBHOOK_URL:
        raise ValueError("A variável de ambiente 'N8N_WEBHOOK_URL' não está definida.")
    if not SQS_QUEUE_URL:
        raise ValueError("A variável de ambiente 'SQS_QUEUE_URL' não está definida.")
    
    sqs = boto3.client('sqs')
    
    for record in event.get("Records", []):
        try:
            message_body = json.loads(record["body"])  # Supondo que a mensagem seja um JSON
            response = requests.post(WEBHOOK_URL, json=message_body)
            
            if response.status_code != 200:
                print(f"Erro ao enviar para o webhook: {response.status_code} - {response.text}")
            else:
                print(f"Mensagem enviada com sucesso: {message_body}")
        
        except json.JSONDecodeError as e:
            print(f"Erro ao decodificar JSON da mensagem: {str(e)}")
        except Exception as e:
            print(f"Erro inesperado: {str(e)}")
    
    return {"statusCode": 200, "body": "Mensagens processadas."}